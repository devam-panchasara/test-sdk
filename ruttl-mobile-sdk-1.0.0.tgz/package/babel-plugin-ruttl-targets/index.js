/**
 * Babel plugin: injects stable Ruttl testIDs and composed onLayout hooks on JSX.
 *
 * Instruments every call-site component (ThemedText, HintRow, View, …), not only
 * RN primitives. Custom wrappers must forward `testID` and `onLayout` to a
 * native host child.
 *
 * Enable in the host app babel.config.js (required):
 *   plugins: ["@ruttl/mobile-sdk/babel-plugin-ruttl-targets"]
 */
const path = require("node:path");

const INSTRUMENT_TAG = /^__ruttl_/;

const SKIP_JSX_NAMES = new Set([
  "Children",
  "Consumer",
  "Fragment",
  "Profiler",
  "Slot",
  "StrictMode",
  "Suspense",
]);

const BOOT_MODULE = "@ruttl/mobile-sdk/instrumentation-boot";

const TEXT_LIKE = /Text$/;

const isRuttlSdkFile = (filename) =>
  /[/\\]@ruttl[/\\]mobile-sdk[/\\]/.test(filename) ||
  /[/\\]packages[/\\]mobile-sdk[/\\]/.test(filename);

const shouldSkipFile = (filename) => {
  if (!filename || filename.includes("node_modules")) return true;

  return isRuttlSdkFile(filename);
};

const slugify = (value) =>
  value
    .replace(/[^a-zA-Z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .toLowerCase() || "file";

const fileSlug = (filename, cwd) => {
  const relative = cwd ? path.relative(cwd, filename) : filename;

  return slugify(relative.replace(/\.[^.]+$/, ""));
};

const getJsxDisplayName = (openingPath) => {
  const nameNode = openingPath.node.name;

  if (nameNode.type === "JSXIdentifier") return nameNode.name;

  if (nameNode.type === "JSXMemberExpression") {
    const objectName =
      nameNode.object.type === "JSXIdentifier"
        ? nameNode.object.name
        : nameNode.object.type === "JSXMemberExpression"
          ? `${nameNode.object.object.name}.${nameNode.object.property.name}`
          : null;

    if (!objectName) return nameNode.property.name;

    return `${objectName}.${nameNode.property.name}`;
  }

  return null;
};

const shouldSkipJsx = (displayName, nameNode) => {
  if (!displayName) return true;

  if (SKIP_JSX_NAMES.has(displayName)) return true;

  if (
    nameNode.type === "JSXMemberExpression" &&
    nameNode.property.name === "Provider"
  ) {
    return true;
  }

  const leaf = displayName.includes(".")
    ? displayName.split(".").pop()
    : displayName;

  return !leaf || !/^[A-Z]/.test(leaf);
};

const getLiteralProp = (openingPath, propName) => {
  const attr = openingPath
    .get("attributes")
    .find(
      (attribute) =>
        attribute.isJSXAttribute() &&
        attribute.node.name.name === propName &&
        (attribute.node.value?.type === "StringLiteral" ||
          attribute.node.value?.type === "Literal"),
    );

  if (!attr) return undefined;

  const value = attr.node.value;

  if (!value) return undefined;

  return value.type === "StringLiteral" || value.type === "Literal"
    ? value.value
    : undefined;
};

const siblingIndex = (jsxPath, displayName) => {
  const parent = jsxPath.parentPath;

  if (!parent.isJSXElement() && !parent.isJSXFragment()) return 1;

  const siblings = parent
    .get("children")
    .filter(
      (child) =>
        child.isJSXElement() &&
        getJsxDisplayName(child.get("openingElement")) === displayName,
    );

  const index = siblings.findIndex((child) => child.node === jsxPath.node);

  return index === -1 ? 1 : index + 1;
};

const buildSelector = (jsxPath, displayName, index, fileLabel) => {
  const segments = [`${displayName}[${index}]`];
  let current = jsxPath.parentPath;

  while (current && !current.isProgram()) {
    if (current.isJSXElement()) {
      const opening = current.get("openingElement");
      const parentName = getJsxDisplayName(opening);

      if (
        parentName &&
        !shouldSkipJsx(parentName, opening.node.name)
      ) {
        const parentIndex = siblingIndex(current, parentName);
        segments.unshift(`${parentName}[${parentIndex}]`);
      }
    }

    current = current.parentPath;
  }

  segments.unshift(fileLabel);

  return segments.join(" > ");
};

const buildCallSiteTestId = (label, displayName, jsxPath) => {
  const loc = jsxPath.node.loc?.start;
  const line = loc?.line ?? 0;
  const col = loc?.column ?? 0;

  return `__ruttl_${label}_${displayName}_L${line}C${col}`;
};

const ensureBootImport = (programPath, state, t) => {
  if (state.bootImportInjected) return;

  const markImport = t.importDeclaration(
    [
      t.importSpecifier(
        t.identifier("__ruttlMarkInstrumented"),
        t.identifier("__ruttlMarkInstrumented"),
      ),
      t.importSpecifier(
        t.identifier("__ruttlRegisterFromLayout"),
        t.identifier("__ruttlRegisterFromLayout"),
      ),
    ],
    t.stringLiteral(BOOT_MODULE),
  );

  const markCall = t.expressionStatement(
    t.callExpression(t.identifier("__ruttlMarkInstrumented"), []),
  );

  programPath.unshiftContainer("body", markImport);
  programPath.get("body.0").insertAfter(markCall);

  state.bootImportInjected = true;
};

const buildMetaObject = (t, meta) =>
  t.objectExpression([
    t.objectProperty(t.identifier("testID"), t.stringLiteral(meta.testID)),
    t.objectProperty(t.identifier("selector"), t.stringLiteral(meta.selector)),
    t.objectProperty(
      t.identifier("componentName"),
      t.stringLiteral(meta.componentName),
    ),
    t.objectProperty(
      t.identifier("text"),
      meta.text ? t.stringLiteral(meta.text) : t.nullLiteral(),
    ),
    t.objectProperty(
      t.identifier("accessibilityLabel"),
      meta.accessibilityLabel
        ? t.stringLiteral(meta.accessibilityLabel)
        : t.nullLiteral(),
    ),
    t.objectProperty(
      t.identifier("role"),
      meta.role ? t.stringLiteral(meta.role) : t.nullLiteral(),
    ),
  ]);

const buildOnLayoutHandler = (t, existingHandler, meta) => {
  const eventParam = t.identifier("event");
  const metaArg = buildMetaObject(t, meta);

  const registerCall = t.expressionStatement(
    t.callExpression(t.identifier("__ruttlRegisterFromLayout"), [
      eventParam,
      metaArg,
    ]),
  );

  const statements = existingHandler
    ? [
        t.expressionStatement(
          t.callExpression(existingHandler, [eventParam]),
        ),
        registerCall,
      ]
    : [registerCall];

  return t.arrowFunctionExpression(
    [eventParam],
    t.blockStatement(statements),
  );
};

const getTextChildLiteral = (jsxPath) => {
  const children = jsxPath.get("children");

  for (const child of children) {
    if (child.isJSXText()) {
      const trimmed = child.node.value.replace(/\s+/g, " ").trim();

      if (trimmed) return trimmed;
    }

    if (
      child.isJSXExpressionContainer() &&
      child.get("expression").isStringLiteral()
    ) {
      return child.get("expression").node.value;
    }
  }

  return null;
};

module.exports = function ruttlTargetsBabelPlugin({ types: t }) {
  return {
    name: "babel-plugin-ruttl-targets",
    visitor: {
      JSXOpeningElement(jsxPath, state) {
        const filename = state.file.opts.filename;

        if (shouldSkipFile(filename)) return;

        const nameNode = jsxPath.node.name;
        const displayName = getJsxDisplayName(jsxPath);

        if (shouldSkipJsx(displayName, nameNode)) return;

        const existingTestId = getLiteralProp(jsxPath, "testID");

        if (existingTestId && INSTRUMENT_TAG.test(existingTestId)) return;

        const index = siblingIndex(jsxPath.parentPath, displayName);
        const label = fileSlug(filename, state.cwd);
        const testID =
          existingTestId ??
          buildCallSiteTestId(label, displayName, jsxPath.parentPath);
        const selector = buildSelector(
          jsxPath.parentPath,
          displayName,
          index,
          label,
        );

        const text =
          displayName === "Text" || TEXT_LIKE.test(displayName)
            ? getTextChildLiteral(jsxPath.parentPath)
            : null;
        const accessibilityLabel = getLiteralProp(
          jsxPath,
          "accessibilityLabel",
        );
        const role =
          getLiteralProp(jsxPath, "accessibilityRole") ??
          getLiteralProp(jsxPath, "role");

        const meta = {
          testID,
          selector,
          componentName: displayName,
          text,
          accessibilityLabel: accessibilityLabel ?? null,
          role: role ?? null,
        };

        if (!existingTestId) {
          jsxPath.node.attributes.push(
            t.jsxAttribute(t.jsxIdentifier("testID"), t.stringLiteral(testID)),
          );
        }

        const onLayoutAttr = jsxPath
          .get("attributes")
          .find(
            (attribute) =>
              attribute.isJSXAttribute() &&
              attribute.node.name.name === "onLayout",
          );

        let existingHandler = null;

        if (onLayoutAttr) {
          const valuePath = onLayoutAttr.get("value");

          if (valuePath.isJSXExpressionContainer()) {
            existingHandler = valuePath.get("expression").node;
          }

          onLayoutAttr.remove();
        }

        jsxPath.node.attributes.push(
          t.jsxAttribute(
            t.jsxIdentifier("onLayout"),
            t.jsxExpressionContainer(
              buildOnLayoutHandler(t, existingHandler, meta),
            ),
          ),
        );

        const programPath = jsxPath.findParent((parent) => parent.isProgram());

        if (programPath) {
          ensureBootImport(programPath, state, t);
        }

        state.instrumentedThisFile = true;
      },
    },
  };
};

module.exports.INSTRUMENT_TAG = INSTRUMENT_TAG;
